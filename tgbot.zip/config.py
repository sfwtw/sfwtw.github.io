# 支付超时时间(秒)
PAY_TIMEOUT = 600
# BOT API
TOKEN = '1693078350:AAGqX2Cyc0CkBjXmIu_EYc6LktmgMTqHH-o'
# ADMIN ID
ADMIN_ID = [630821049]

# 管理员命令
ADMIN_COMMAND_START = 'iadmin'
ADMIN_COMMAND_QUIT = 'icancel'

# 支持的支付方式
PAYMENT_METHOD = {
    'epay': '支付宝/微信/QQ',
}

# 当前版本
VERSION = '1.3.5'
